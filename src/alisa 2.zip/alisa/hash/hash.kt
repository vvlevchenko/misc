package alisa.hash

class HashTable(val nbucket:Int, val hash:(Int)->Int = ::identity) {
    private val bucket =  Array(nbucket){ mutableListOf<Pair<Int, Int>>()}

    private fun lookup(key:Int) = bucket[hash(key) % nbucket].find { it.first == key }

    fun add(key: Int, value:Int) {
        remove(key)
        bucket[hash(key) % nbucket].add(key to value)
    }

    fun remove(key:Int) {
        lookup(key)?.let { bucket[hash(key) % nbucket].remove(it) }
    }

    operator fun get(key:Int):Int? = lookup(key)?.second
    operator fun set(key: Int, value: Int) = add(key, value)
}

fun identity(i:Int) = i