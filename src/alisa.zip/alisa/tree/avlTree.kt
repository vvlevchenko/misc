package alisa.tree

open class avl_Node(var Root : Boolean):Node(){

    fun diff(): Int  = (Left?.length() ?: 0) - (Right?.length() ?: 0)

    fun Node.length(): Int = (Right?.length() ?: 0) + (Left?.length() ?: 0) + 1
/*
    fun balanced(node : avl_Node){
        if ((diff(node) == -2) && (( diff(node.Right) == 1) || ( diff(node.Right) == -1) || (diff(node.Right) == 0))){
            little_left_rotate(node)
        }
        else if ((diff(node) == 2) && (( diff(node.Right) == 1) || ( diff(node.Right) == -1) || (diff(node.Right) == 0))){
            little_left_rotate(node)
        }
        else if ( (diff(node) == -2) && ((diff(node?.Right) == 1) && (((diff(node?.Right?.Left) ==  -1) || (diff(node?.Right?.Left) ==  0) )))){
            big_left_rotate(node)
        }
        else{
            big_right_rotate(node)
        }
    }

    fun little_left_rotate(node: avl_Node?) {
        node?.let{
            node.Root = false
            node.Right?.Root = true
            node.Right?.Parent = null
            node.Parent = node.Right
            node.Right = node.Right?.Left
            node.Parent?.Left = node
    }
}

    fun little_right_rotate(node : avl_Node?){
        node?.let{
            node.Root = false
            node.Left?.Root = true
            node.Left?.Parent = null
            node.Parent = node.Left
            node.Left = node.Left?.Right
            node.Parent?.Right = node
        }
    }

    fun big_left_rotate(node : avl_Node?){
        little_right_rotate(node?.Right)
        little_left_rotate(node)
    }

    fun big_right_rotate(node : avl_Node){
        little_left_rotate(node?.Left)
        little_right_rotate(node)
    }
*/
}