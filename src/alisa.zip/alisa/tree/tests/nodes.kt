package alisa.tree.tests

import alisa.tree.Node
import kotlin.test.assertEquals

/**
 *                   8
 *                 /  \
 *                 3  10
 *               / |     \
 *              1  6     14
 *                / \    /
 *               4  7    13
 */
val tree: Node = with(Node(8)) {
    create(3)
    create(10)
    create(1)
    create(6)
    create(14)
    create(4)
    create(7)
    create(13)
}

fun Node.dump():String = buildString {
    append('(').append(Value)
    Left?.let {
        append(", ")
        append("L").append(it.dump())
        Right?.let{append(", ")}
    } ?: append(' ')
    Right?.let { append("R").append(it.dump()) }
    append(')')
}

fun Node.copy():Node = accept(Node(Value)) { root ->
    Left?.run{ root.create(Value) }
    Right?.run { root.create(Value) }
    root
}

fun test() {
    println(tree.dump())
    assertEquals(3, tree.min_finder(2)?.Value)
    assertEquals(10, tree.min_finder(9)?.Value)
    assertEquals(13, tree.min_finder(11)?.Value)
    assertEquals(4, tree.max_finder(5)?.Value)

    val toDelete14 = tree.copy()
    println(toDelete14.dump())
    toDelete14.delete(14)
    println(toDelete14)
}

fun main() {
    test()
}